exports.id=77,exports.ids=[77],exports.modules={4978:(s,r,a)=>{"use strict";a.d(r,{W:()=>GlassCard});var e=a(997);a(6689);let GlassCard=({children:s,className:r="",hoverEffect:a=!0})=>e.jsx("div",{className:`
        bg-glass-white 
        backdrop-blur-md 
        border border-glass-stroke 
        rounded-2xl 
        shadow-glass 
        p-6 
        transition-all 
        duration-300 
        ${a?"hover:bg-opacity-20 hover:scale-[1.02] hover:shadow-glow":""}
        ${r}
      `,children:s})},5913:(s,r,a)=>{"use strict";a.r(r),a.d(r,{default:()=>App});var e=a(997);function App({Component:s,pageProps:r}){return e.jsx(s,{...r})}a(6764)},6764:()=>{}};